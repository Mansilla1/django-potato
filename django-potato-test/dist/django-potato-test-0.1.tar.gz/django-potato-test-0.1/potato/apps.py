from django.apps import AppConfig


class PotatoConfig(AppConfig):
    name = 'potato'
